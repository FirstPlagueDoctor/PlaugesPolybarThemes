#!/bin/bash

# Get WiFi interface dynamically (clean output)
INTERFACE=$(nmcli device status | grep wifi | head -1 | awk '{print $1}' | tr -d '\r\n\033\007')

if [ -z "$INTERFACE" ]; then
    echo "󰖪 WiFi"
    exit 1
fi

# Get connection status (clean output)
CONNECTION=$(nmcli -t -f NAME connection show --active | grep -v "lo\|docker\|virbr" | head -1 | tr -d '\r\n\033\007')

if [ -n "$CONNECTION" ]; then
    # Connected - get signal strength (clean output)
    SIGNAL=$(nmcli -f IN-USE,SIGNAL device wifi list | grep "^\*" | awk '{print $2}' | tr -d '\r\n\033\007')
    
    if [ -n "$SIGNAL" ]; then
        if [ "$SIGNAL" -gt 80 ]; then
            ICON="󰤨"
        elif [ "$SIGNAL" -gt 60 ]; then
            ICON="󰤥"
        elif [ "$SIGNAL" -gt 40 ]; then
            ICON="󰤢"
        elif [ "$SIGNAL" -gt 20 ]; then
            ICON="󰤟"
        else
            ICON="󰤯"
        fi
        echo "$ICON $CONNECTION"
    else
        echo "󰤭 $CONNECTION"
    fi
else
    echo "󰖪 Disconnected"
fi
