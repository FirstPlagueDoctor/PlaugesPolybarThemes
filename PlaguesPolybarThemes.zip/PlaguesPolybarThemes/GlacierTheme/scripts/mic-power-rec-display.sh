#!/bin/bash
# Save as: ~/.config/polybar/scripts/mic-power-rec-display.sh

# Customizable colors - edit these to match your theme
MIC_MUTED_COLOR="#ff5555"    # Red for muted MIC
MIC_UNMUTED_COLOR="#51cf66"  # Green for unmuted MIC
POWER_COLOR="#914047"        # Gray for POWER  
REC_COLOR="#ff5555"          # Red for REC
SEPARATOR_COLOR="#d3d3d3"    # White for separators
RESET_COLOR="%{F-}"          # Reset to default

# Check mic status - determine color only
if pactl get-source-mute @DEFAULT_SOURCE@ | grep -q "yes"; then
    MIC_COLOR="$MIC_MUTED_COLOR"  # Red when muted
else
    MIC_COLOR="$MIC_UNMUTED_COLOR"  # Green when unmuted
fi

# Always display "MIC" text, just change the color
echo "%{F$MIC_COLOR}MIC$RESET_COLOR %{F$SEPARATOR_COLOR}|$RESET_COLOR %{F$POWER_COLOR}POWER$RESET_COLOR %{F$SEPARATOR_COLOR}|$RESET_COLOR %{F$REC_COLOR}REC$RESET_COLOR"
