#!/bin/bash
# Save as: ~/.config/polybar/scripts/mic-power-rec-click.sh

# Simple menu to choose which action
choice=$(echo -e "MIC\nPOWER\nREC" | rofi -dmenu -p "Choose action:")

case $choice in
    "MIC")
        ~/.config/polybar/scripts/mic_toggle.sh
        ;;
    "POWER")
        ~/.config/polybar/scripts/power-menu.sh
        ;;
    "REC")
        ~/.config/polybar/scripts/obs-toggle.sh
        ;;
esac
