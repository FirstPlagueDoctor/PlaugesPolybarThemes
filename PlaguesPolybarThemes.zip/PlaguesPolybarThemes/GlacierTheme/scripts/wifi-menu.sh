#!/bin/bash

# WiFi Menu Script for Polybar with Rofi
# This script shows available WiFi networks and allows connection

# Function to get WiFi status
get_wifi_status() {
    nmcli radio wifi
}

# Function to get current connection
get_current_connection() {
    nmcli -t -f NAME connection show --active | grep -v "lo\|docker\|virbr"
}

# Function to scan and get available networks
get_available_networks() {
    nmcli device wifi rescan >/dev/null 2>&1
    sleep 1
    nmcli -f SSID,SECURITY,SIGNAL device wifi list | \
    awk 'NR>1 && $1!="" {
        ssid = $1
        security = $2
        signal = $3
        
        # Add lock icon for secured networks
        if (security == "--") {
            printf "%s\n", ssid
        } else {
            printf "🔒 %s\n", ssid
        }
    }' | sort -u
}

# Main menu function
show_menu() {
    local current_connection=$(get_current_connection)
    local wifi_status=$(get_wifi_status)
    
    # Build menu options
    local options=""
    
    # Add current connection info
    if [ -n "$current_connection" ]; then
        options+="✓ Connected to: $current_connection\n"
        options+="🔌 Disconnect\n"
    fi
    
    # Add WiFi toggle
    if [ "$wifi_status" = "enabled" ]; then
        options+="📶 Turn WiFi Off\n"
    else
        options+="📶 Turn WiFi On\n"
    fi
    
    options+="🔄 Refresh Networks\n"
    options+="⚙️ Network Settings\n"
    options+="────────────────\n"
    
    # Add available networks if WiFi is enabled
    if [ "$wifi_status" = "enabled" ]; then
        local networks=$(get_available_networks)
        if [ -n "$networks" ]; then
            options+="$networks"
        else
            options+="No networks found"
        fi
    fi
    
    # Show rofi menu
    echo -e "$options" | rofi -dmenu -i -p "WiFi Networks" \
        -theme-str 'window {width: 400px;}'
}

# Function to connect to network
connect_to_network() {
    local network="$1"
    
    # Remove lock icon if present
    network=$(echo "$network" | sed 's/🔒 //')
    
    # Check if network requires password
    local security=$(nmcli -f SSID,SECURITY device wifi list | grep "^$network" | awk '{print $2}')
    
    if [ "$security" != "--" ]; then
        # Network is secured, prompt for password
        local password=$(rofi -dmenu -password -p "Password for $network")
        
        if [ -n "$password" ]; then
            nmcli device wifi connect "$network" password "$password"
        else
            exit 0
        fi
    else
        # Open network
        nmcli device wifi connect "$network"
    fi
    
    # Check connection status
    if [ $? -eq 0 ]; then
        notify-send "WiFi" "Connected to $network" -i network-wireless
    else
        notify-send "WiFi" "Failed to connect to $network" -i network-wireless-disconnected
    fi
}

# Main script logic
main() {
    local choice=$(show_menu)
    
    case "$choice" in
        "🔌 Disconnect")
            nmcli connection down "$(get_current_connection)"
            notify-send "WiFi" "Disconnected" -i network-wireless-disconnected
            ;;
        "📶 Turn WiFi Off")
            nmcli radio wifi off
            notify-send "WiFi" "WiFi turned off" -i network-wireless-disabled
            ;;
        "📶 Turn WiFi On")
            nmcli radio wifi on
            notify-send "WiFi" "WiFi turned on" -i network-wireless
            ;;
        "🔄 Refresh Networks")
            nmcli device wifi rescan
            notify-send "WiFi" "Networks refreshed" -i network-wireless
            ;;
        "⚙️ Network Settings")
            nm-connection-editor &
            ;;
        "✓ Connected to:"* | "No networks found" | "────────────────" | "")
            # Do nothing for info lines
            ;;
        *)
            # Try to connect to selected network
            if [ -n "$choice" ]; then
                connect_to_network "$choice"
            fi
            ;;
    esac
}

# Run main function
main
