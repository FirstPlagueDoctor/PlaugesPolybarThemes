#!/bin/bash
# OBS Toggle Script for Polybar
# Save as: ~/.config/polybar/scripts/obs-toggle.sh

if pgrep -x "obs" > /dev/null; then
    # OBS is running, you could send commands to it here
    # For now, just focus the window or restart it
    pkill obs
    sleep 1
    obs &
else
    # Start OBS
    obs &
fi

# Alternative version that just opens OBS without toggling:
# obs &

# Don't forget to make it executable:
# chmod +x ~/.config/polybar/scripts/obs-toggle.sh
