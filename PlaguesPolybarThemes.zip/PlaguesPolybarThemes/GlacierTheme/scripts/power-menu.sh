#!/bin/bash

choice=$(echo -e "Shutdown\nRestart\nLogout" | rofi -dmenu -i -p "Power Menu")

case $choice in
    "Shutdown")
        systemctl poweroff
        ;;
    "Restart")
        systemctl reboot
        ;;
    "Logout")
        cinnamon-session-quit --logout
        ;;
esac
