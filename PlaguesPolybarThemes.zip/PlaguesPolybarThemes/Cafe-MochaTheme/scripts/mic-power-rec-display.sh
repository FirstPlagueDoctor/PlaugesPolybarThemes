#!/bin/bash
# Save as: ~/.config/polybar/scripts/mic-power-rec-display.sh

# Customizable colors - edit these to match your theme
MIC_MUTED_COLOR="#803D3B"    # Brown for muted MIC
MIC_UNMUTED_COLOR="#3F4E4F"  # Yellow for unmuted MIC
POWER_COLOR="#6F4E37"        # Dark Red for POWER 6C4E31 
REC_COLOR="#914047"          #  for REC
SEPARATOR_COLOR="#d3d3d3"    # White for separators
RESET_COLOR="%{F-}"          # Reset to default

# Check mic status - determine color only
if pactl get-source-mute @DEFAULT_SOURCE@ | grep -q "yes"; then
    MIC_COLOR="$MIC_MUTED_COLOR"  # Red when muted
else
    MIC_COLOR="$MIC_UNMUTED_COLOR"  # Green when unmuted
fi

# Always display "MIC" text, just change the color
echo "%{F$MIC_COLOR}MIC$RESET_COLOR %{F$SEPARATOR_COLOR}|$RESET_COLOR %{F$POWER_COLOR}POWER$RESET_COLOR %{F$SEPARATOR_COLOR}|$RESET_COLOR %{F$REC_COLOR}REC$RESET_COLOR"
