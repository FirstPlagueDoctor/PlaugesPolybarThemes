#!/bin/bash
# ~/.config/polybar/scripts/mic_status.sh

# Get the default source (microphone)
DEFAULT_SOURCE=$(pactl get-default-source)

# Check if microphone is muted
IS_MUTED=$(pactl get-source-mute "$DEFAULT_SOURCE" | grep -o "yes\|no")

# Use environment variables for text and colors, with defaults
MIC_MUTED_TEXT="${MIC_MUTED_TEXT:-MIC OFF}"
MIC_UNMUTED_TEXT="${MIC_UNMUTED_TEXT:-MIC ON}"
MIC_MUTED_COLOR="${MIC_MUTED_COLOR:-#ff6b6b}"
MIC_UNMUTED_COLOR="${MIC_UNMUTED_COLOR:-#51cf66}"

if [ "$IS_MUTED" = "yes" ]; then
    echo "%{F$MIC_MUTED_COLOR}$MIC_MUTED_TEXT%{F-}"
else
    echo "%{F$MIC_UNMUTED_COLOR}$MIC_UNMUTED_TEXT%{F-}"
fi
