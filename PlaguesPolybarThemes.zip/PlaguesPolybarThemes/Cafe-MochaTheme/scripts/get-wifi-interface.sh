#!/bin/bash
# Get the first wireless interface
nmcli device status | grep wifi | head -1 | awk '{print $1}'
