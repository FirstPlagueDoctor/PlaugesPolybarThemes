#!/bin/bash
# ~/.config/polybar/scripts/mic_toggle.sh

# Get the default source (microphone)
DEFAULT_SOURCE=$(pactl get-default-source)

# Toggle microphone mute
pactl set-source-mute "$DEFAULT_SOURCE" toggle
